function callBombingRun(bombs) {
    var i;
    if (typeof bombs == 'undefined') {
        bombs = 3;
    }

    this.up(100)
        .left(1);
    this.chkpt('plane');
    for (i = 0; i < bombs; i++) {
        this
            .box(blocks.tnt, 3, 1, 3)
            .move(plane)
            .up(1)
            .chkpt(planeTwo)
            .box(blocks.redstone, 3, 1, 3)
            .move(planeTwo)
            .box(blocks.air, 3, 1, 3)
            .move(plane)
            .fwd(6);
    }
    this.move('plane');

};
var Drone = require('drone');
Drone.extend(callBombingRun);