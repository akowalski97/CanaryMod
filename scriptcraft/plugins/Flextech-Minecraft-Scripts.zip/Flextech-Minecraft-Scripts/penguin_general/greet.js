exports.greet = function( player ) {
    echo( player, 'Hi ' + player.name);
}